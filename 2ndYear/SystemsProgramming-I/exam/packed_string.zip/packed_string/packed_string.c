//   packed_string.c
//   David Gregg
//   December 2022

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include "packed_string.h"


// pack the 7-bit values of the string into memory
unsigned char * string_to_packed(char * string) {

}



// unpack bytes of memory containing 7-bit characters into a string
char * packed_to_string(unsigned char * packed_string) {

}


